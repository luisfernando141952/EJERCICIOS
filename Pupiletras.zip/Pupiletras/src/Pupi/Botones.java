package Pupi;


import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;



public class Botones extends JButton implements ActionListener{
    public Botones(int posx,int posy,int ancho,int alto){
        setBounds(posx, posy, ancho, alto);
        addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e){
        setBackground(Color.blue);
    }
    
}
